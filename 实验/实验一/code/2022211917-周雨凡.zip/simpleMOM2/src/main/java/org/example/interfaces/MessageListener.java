package org.example.interfaces;

public interface MessageListener {
    void onMessageChanged(MessageQueue queue);
}